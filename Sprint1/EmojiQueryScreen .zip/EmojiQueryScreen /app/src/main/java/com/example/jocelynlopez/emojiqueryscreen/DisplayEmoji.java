package com.example.jocelynlopez.emojiqueryscreen;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.content.Intent;


public class DisplayEmoji extends AppCompatActivity {
    private SeekBar seekBar;
    private Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_emoji);
        final Button button2 = (Button) findViewById(R.id.button2);
        seekBar = (SeekBar)findViewById(R.id.seekBar5);
        spinner = (Spinner) findViewById(R.id.spinner);


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int progressMoved = 0;

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progressMoved = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DisplayEmoji.this, Emoji_Selected.class);
                startActivity(intent);

            }
        });

    }
}
