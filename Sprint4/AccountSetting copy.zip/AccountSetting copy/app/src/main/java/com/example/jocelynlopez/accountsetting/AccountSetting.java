package com.example.jocelynlopez.accountsetting;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;



public class AccountSetting extends AppCompatActivity {

    private EditText editText2;//username
    private EditText editText;//phone number
    private EditText editText5;//password
    private Button submitChanges;
    private Button changePassword;
    private String newUsername;
    private String newPhone;
    private String password;
    //public static String token = "";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_page);

        submitChanges = findViewById(R.id.button);
        changePassword = findViewById(R.id.button2);

        editText = findViewById(R.id.editText);
        editText2 = findViewById(R.id.editText2);
        editText5 = findViewById(R.id.editText5);

        newUsername = editText2.getText().toString().trim();
        newPhone = editText.getText().toString().trim();
        password = editText5.getText().toString().trim();


        //update password
        changePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AccountSetting.this, ChangePassword.class);
                startActivity(intent);
            }
        });

        //update username and phonenumber
        submitChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateAccount(newUsername,password,newPhone);
            }
        });



    }

    public void updateAccount(final String user, final String password,final String phone){

        final RequestQueue MyRequestQueue = Volley.newRequestQueue(this);
        String URL = "http://www.emoji-survey.me/auth/users/change_username/";
        StringRequest sr = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                MyRequestQueue.stop();
                Intent intent = new Intent (AccountSetting.this, SuccessfulUpdate.class);
                startActivity(intent);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
                MyRequestQueue.stop();
                AlertDialog.Builder builder = new AlertDialog.Builder(AccountSetting.this);
                builder.setMessage("Change Unsuccesful")
                        .setNegativeButton("Retry", null)
                        .create()
                        .show();

            }
        }){
            public Map getHeaders() throws AuthFailureError {
                HashMap headers = new HashMap();
                headers.put("Authorization", "Token " + LoginActivity.token);
                return headers;
            }
            public Map<String, String> getParams() {
                Map<String, String> MyData = new HashMap<String, String>();
                MyData.put("current_password", password);
                MyData.put("new_username", user);
                return MyData;
            }
        };

        MyRequestQueue.add(sr);

    }
}
