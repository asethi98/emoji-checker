package com.example.jocelynlopez.accountsetting;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class ChangePassword extends AppCompatActivity {

    private EditText editText3;
    private EditText editText4;
    private Button changePassword;
    private String current_password;
    private String new_password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        editText3 = findViewById(R.id.editText3);
        editText4 = findViewById(R.id.editText4);
        current_password = editText3.getText().toString();
        new_password = editText4.getText().toString();
        changePassword = findViewById(R.id.button3);


        changePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updatePassword(current_password,new_password);

            }
        });

    }


    public void updatePassword(final String currentPass, final String newPass){
        final RequestQueue MyRequestQueue = Volley.newRequestQueue(this);
        String URL = "http://www.emoji-survey.me/auth/password";
        StringRequest sr = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                MyRequestQueue.stop();
                Intent intent = new Intent (ChangePassword.this, PassSuccess.class);
                ChangePassword.this.startActivity(intent);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                MyRequestQueue.stop();
                AlertDialog.Builder builder = new AlertDialog.Builder(ChangePassword.this);
                builder.setMessage("Password change Failed")
                        .setNegativeButton("Retry", null)
                        .create()
                        .show();
            }
        }){
            public Map getHeaders() throws AuthFailureError {
                HashMap headers = new HashMap();
                headers.put("Authorization", "Token " + LoginActivity.token);
                return headers;
            }
            public Map<String, String> getParams() {
                Map<String, String> MyData = new HashMap<String, String>();
                MyData.put("new_password", newPass);
                MyData.put("current_password", currentPass);
                return MyData;
            }
        };

        MyRequestQueue.add(sr);
    }
}
