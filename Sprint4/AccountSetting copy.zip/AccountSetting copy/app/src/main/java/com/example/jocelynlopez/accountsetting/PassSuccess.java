package com.example.jocelynlopez.accountsetting;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class PassSuccess extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pass_success);
    }
}
