package com.example.michaelwheeler.emojichecker;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
/*
I when ahead and put everything in one file but not sure How volley works to connect everything together
follow how I did the connect in the main activity It starts in line 39-69 of course just use correct names
 */


import java.util.HashMap;
import java.util.Map;

public class QueryActivity extends AppCompatActivity {
    private TextView textView;
    private SeekBar seekBar;
    private Button submitButton;
    private ImageView image1, image2, image3, image4, image5, image6, image7, image8, image9;
    private String url = "http://emoji-survey.me/responses/?format=json";
    int[] emojis = {R.drawable.sleepy, R.drawable.angry, R.drawable.nervous, R.drawable.passive, R.drawable.confused,
            R.drawable.neutral, R.drawable.content, R.drawable.giggly, R.drawable.happy};

    String keyword = "";
    int min = 1, max = 9, current = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        image1 = (ImageView) findViewById(R.id.sleepyImageView);
        image2 = (ImageView) findViewById(R.id.angryImageView);
        image3 = (ImageView) findViewById(R.id.nervousImageView);
        image4 = (ImageView) findViewById(R.id.passiveImageView);
        image5 = (ImageView) findViewById(R.id.confusedImageView);
        image6 = (ImageView) findViewById(R.id.neutralImageView);
        image7 = (ImageView) findViewById(R.id.contentImageView);
        image8 = (ImageView) findViewById(R.id.gigglyImageView);
        image9 = (ImageView) findViewById(R.id.happyImageView);


        submitButton = (Button) findViewById(R.id.submitButton);
        textView = (TextView) findViewById(R.id.textView);
        seekBar = (SeekBar) findViewById(R.id.seekBar);

        seekBar.setMax(max - min);
        seekBar.setProgress(current - min);
        textView.setText("Sleepy");


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                current = progress + min;
                sliderEnabled(current);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Send selected emoji from slider to the server and display the correct screen
                sendEmoji();
            }
        });

    }

    public String sliderEnabled(int current) {
        //Map the value of the slider to each emoji
        switch (current) {
            case 1:
                textView.setText("Sleepy");
                image1.setImageResource(emojis[0]);
                keyword = "Sleepy";
                break;
            case 2:
                textView.setText("Angry");
                image2.setImageResource(emojis[1]);
                keyword = "Angry";
                break;
            case 3:
                textView.setText("Nervous");
                image3.setImageResource(emojis[2]);
                keyword = "Nervous";
                break;
            case 4:
                textView.setText("Passive-Aggressive");
                image4.setImageResource(emojis[3]);
                keyword = "Passive-Aggressive";
                break;
            case 5:
                textView.setText("Confused");
                image5.setImageResource(emojis[4]);
                keyword = "Confused";
                break;
            case 6:
                textView.setText("Neutral");
                image6.setImageResource(emojis[5]);
                keyword = "Neutral";
                break;
            case 7:
                textView.setText("Content");
                image7.setImageResource(emojis[6]);
                keyword = "Content";
                break;
            case 8:
                textView.setText("Giggly");
                image8.setImageResource(emojis[7]);
                keyword = "Giggly";
                break;
            case 9:
                textView.setText("Happy");
                image9.setImageResource(emojis[8]);
                keyword = "Happy";
                break;

        }
        return keyword; //Return the string keyword that matches emoji selected by user
    }

    public void sendEmoji() {
        final RequestQueue requestQueue = Volley.newRequestQueue(QueryActivity.this);

        StringRequest stringRequest = new  StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //This code is executed if the server responds, whether or not the response contains data.
                //The String 'response' contains the server's response.
                textView.setText(response);
                requestQueue.stop();
                openActivity2(); //Launch confirmation screen
            }
        }, new Response.ErrorListener() { //Create an error listener to handle errors appropriately.
            @Override
            public void onErrorResponse(VolleyError error) {
                //This code is executed if there is an error.
                //textView.setText("Error Sending Response");
                error.printStackTrace();
                requestQueue.stop();
                openActivity3(); //Launch confirmation screen
            }
        }) {
            protected Map<String, String> getParams() {
                //Add the data to send to the server.
                Map<String, String> MyData = new HashMap<String, String>();
                MyData.put("emoji", keyword);
                MyData.put("ts", "12:00 am");
                MyData.put("user", "A");
                return MyData;
            }
        };
        requestQueue.add(stringRequest);
    }

    public void openActivity2() {
        //Used to launches the confirmation screen
        Intent intent = new Intent(this, screen2.class);
        startActivity(intent);
    }

    public void openActivity3() {
        //Used to launches the confirmation screen
        Intent intent = new Intent(this, screen3.class);
        startActivity(intent);
    }

}

