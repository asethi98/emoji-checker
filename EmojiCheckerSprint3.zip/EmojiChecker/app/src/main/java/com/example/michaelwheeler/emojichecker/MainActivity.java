package com.example.michaelwheeler.emojichecker;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

//this is the opening screen on the app
public class MainActivity extends AppCompatActivity {
    //Button one is logIn
    private Button button1;
    private Button button2;

    //second coder code this needs comments
    private TextView textView;
    private SeekBar seekBar;
    private Button submitButton;


    String keyword = "";
    int min = 1, max = 9, current = 0;

    //Button two is signUp
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );


// This method connects the LogIn Button to the create account page
        button1 = (Button) findViewById( R.id.editLogIn );
        button2 = (Button) findViewById( R.id.editSignUp );
        //set buuton to one to logIN
        button1.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openlogIn();
            }

        } );
//Button2 to connect signup to create account
        button2.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opencreateAccount();
            }

        } );


    }

    // button1 logIn open create account
    public void opencreateAccount() {
        Intent intent = new Intent( this, createAccount.class );
        startActivity( intent );
    }

    //Button 1 open logIn
    public void openlogIn() {
        Intent intent = new Intent( this, logIn.class );
        startActivity( intent );
    }

    //menu


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        //  inflater.inflate( R.menu.main_menu, menu );
        return true;

    }

    //different case to switch from or menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.logIn:
                Intent intent1 = new Intent( this, logIn.class );
                this.startActivity( intent1 );
                return true;
            case R.id.createAccount:
                Intent intent2 = new Intent( this, createAccount.class );
                this.startActivity( intent2 );
                return true;
            default:
                break;


        }
        return super.onOptionsItemSelected( item );
    }

}